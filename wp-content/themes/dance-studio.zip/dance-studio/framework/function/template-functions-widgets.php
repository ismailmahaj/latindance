<?php 
/**
 * @package 	WordPress
 * @subpackage 	Dance Studio
 * @version		1.0.0
 * 
 * Template Functions for Widgets
 * Created by CMSMasters
 * 
 */